package VerteilteSysteme.tryout.testv2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Testv2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
